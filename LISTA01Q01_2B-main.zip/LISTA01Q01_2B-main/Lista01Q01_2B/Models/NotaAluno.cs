﻿namespace Lista01Q01_2B.Models
{
    public class NotaAluno
    {
        public string RaAluno { get; set; }
        public int IdDisciplina { get; set; }
        public double Nota { get; set; }
        public double Frequencia { get; set; }

    }
}
