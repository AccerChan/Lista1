﻿using Lista01Q01_2B.Models;

namespace Lista01Q01_2B.Services
{
    public interface INotaAlunoService
    {
        public void InserirNota(NotaAluno nota);
    }
}
